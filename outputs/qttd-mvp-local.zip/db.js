'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

function createStore(databasePath = path.join(__dirname, 'data', 'qttd.db')) {
  fs.mkdirSync(path.dirname(databasePath), { recursive: true });
  const db = new DatabaseSync(databasePath);
  db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
  db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

  function list(search = '') {
    const query = `%${search.trim()}%`;
    return db.prepare(`
      SELECT h.id, h.ma_ho_so AS code, k.cif, k.ten_khach_hang AS customerName,
             k.ma_chi_nhanh AS branchCode, k.ten_chi_nhanh AS branchName,
             h.so_hdtd AS contractNumber, h.so_tien_vnd AS creditAmount,
             h.trang_thai_ho_so AS status, h.ngay_sua AS updatedAt
      FROM ho_so_cap_td h JOIN khach_hang k ON k.id = h.id_khach_hang
      WHERE ? = '%%' OR h.ma_ho_so LIKE ? OR k.cif LIKE ? OR k.ten_khach_hang LIKE ? OR h.so_hdtd LIKE ?
      ORDER BY h.ngay_sua DESC, h.id DESC
    `).all(query, query, query, query, query);
  }

  function config() {
    const rows = db.prepare(`SELECT loai, ma, ten, mac_dinh
      FROM danh_muc WHERE hieu_luc=1 ORDER BY loai, thu_tu, id`).all();
    return rows.reduce((result, row) => {
      (result[row.loai] ||= []).push({ value:row.ma, label:row.ten, isDefault:!!row.mac_dinh });
      return result;
    }, {});
  }

  function get(id) {
    const row = db.prepare(`SELECT h.*, k.*,
      h.id AS file_id, k.id AS customer_id, h.ngay_tao AS file_created_at, h.ngay_sua AS file_updated_at
      FROM ho_so_cap_td h JOIN khach_hang k ON k.id=h.id_khach_hang WHERE h.id=?`).get(id);
    if (!row) return null;
    const conditions = db.prepare('SELECT * FROM dieu_kien WHERE id_ho_so=? ORDER BY nhom_dk, thu_tu, id').all(id).map(mapCondition);
    const periodStmt = db.prepare('SELECT * FROM ky_theo_doi_dk WHERE id_dieu_kien=? ORDER BY id');
    for (const condition of conditions) condition.periods = periodStmt.all(condition.id).map(mapPeriod);
    return {
      id: row.file_id,
      version: row.version,
      customer: mapCustomer(row),
      file: mapFile(row),
      capitalMembers: db.prepare('SELECT * FROM co_cau_von WHERE id_khach_hang=? ORDER BY thu_tu, id').all(row.customer_id).map(mapCapital),
      relatedPartners: db.prepare('SELECT * FROM doi_tac_lien_quan WHERE id_ho_so=? ORDER BY thu_tu, id').all(id).map(mapPartner),
      conditions,
      debts: db.prepare('SELECT * FROM dieu_kien_no WHERE id_ho_so=? ORDER BY stt, id').all(id).map(mapDebt)
    };
  }

  function save(payload, id = null) {
    const errors = validate(payload);
    if (errors.length) return { validationErrors: errors };
    const now = new Date().toISOString();
    db.exec('BEGIN IMMEDIATE');
    try {
      const oldValue = id ? get(id) : null;
      if (id && !oldValue) throw httpError(404, 'Không tìm thấy hồ sơ.');
      if (id && Number(payload.version) !== Number(oldValue.version)) throw httpError(409, 'Hồ sơ đã được thay đổi ở phiên khác. Hãy tải lại trước khi lưu.');

      const customerId = upsertCustomer(payload.customer, oldValue?.customer?.id, now);
      let fileId = id;
      if (id) updateFile(id, customerId, payload.file, now, oldValue.version);
      else fileId = insertFile(customerId, payload.file, now);

      replaceChildren(fileId, customerId, payload);
      if (!id) {
        const year = (payload.file.reportDate || now).slice(0, 4);
        const code = `QTTD-${cleanCode(payload.customer.branchCode)}-${year}-${String(fileId).padStart(5, '0')}`;
        db.prepare('UPDATE ho_so_cap_td SET ma_ho_so=? WHERE id=?').run(code, fileId);
      }
      const saved = get(fileId);
      db.prepare(`INSERT INTO nhat_ky_he_thong(thoi_diem,hanh_dong,bang,id_ban_ghi,gia_tri_cu,gia_tri_moi)
                  VALUES(?,?,?,?,?,?)`).run(now, id ? 'SUA' : 'TAO', 'ho_so_cap_td', fileId,
                    oldValue ? JSON.stringify(oldValue) : null, JSON.stringify(saved));
      db.exec('COMMIT');
      return saved;
    } catch (error) {
      db.exec('ROLLBACK');
      if (String(error.message).includes('UNIQUE constraint failed: khach_hang.cif')) throw httpError(409, 'CIF đã tồn tại ở khách hàng khác.');
      if (String(error.message).includes('UNIQUE constraint failed: ho_so_cap_td.so_hdtd')) throw httpError(409, 'Số HĐTD đã tồn tại.');
      throw error;
    }
  }

  function upsertCustomer(c, existingId, now) {
    const values = [c.cif.trim(), c.name.trim(), c.type, nullable(c.businessRegistration), nullable(c.businessRegistrationDate),
      nullable(c.taxCode), nullable(c.rating), nullable(c.ratingDate), nullable(c.legalRepresentative), nullable(c.authorizedPerson),
      nullable(c.chiefAccountant), nullable(c.notes), c.branchCode.trim(), c.branchName.trim(), now];
    if (existingId) {
      db.prepare(`UPDATE khach_hang SET cif=?,ten_khach_hang=?,loai_hinh_kh=?,so_gcn_dkkd=?,ngay_cap_dkkd=?,ma_so_thue=?,
        xhtd_hang=?,xhtd_ky=?,nguoi_dai_dien_pl=?,nguoi_duoc_uy_quyen=?,ke_toan_truong=?,luu_y_khac=?,ma_chi_nhanh=?,ten_chi_nhanh=?,ngay_sua=? WHERE id=?`).run(...values, existingId);
      return existingId;
    }
    const found = db.prepare('SELECT id FROM khach_hang WHERE cif=?').get(c.cif.trim());
    if (found) {
      db.prepare(`UPDATE khach_hang SET ten_khach_hang=?,loai_hinh_kh=?,so_gcn_dkkd=?,ngay_cap_dkkd=?,ma_so_thue=?,xhtd_hang=?,xhtd_ky=?,
        nguoi_dai_dien_pl=?,nguoi_duoc_uy_quyen=?,ke_toan_truong=?,luu_y_khac=?,ma_chi_nhanh=?,ten_chi_nhanh=?,ngay_sua=? WHERE id=?`)
        .run(...values.slice(1), found.id);
      return found.id;
    }
    return Number(db.prepare(`INSERT INTO khach_hang(cif,ten_khach_hang,loai_hinh_kh,so_gcn_dkkd,ngay_cap_dkkd,ma_so_thue,xhtd_hang,xhtd_ky,
      nguoi_dai_dien_pl,nguoi_duoc_uy_quyen,ke_toan_truong,luu_y_khac,ma_chi_nhanh,ten_chi_nhanh,ngay_tao,ngay_sua)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(...values, now).lastInsertRowid);
  }

  function insertFile(customerId, f, now) {
    return Number(db.prepare(`INSERT INTO ho_so_cap_td(id_khach_hang,so_qd_cap_td,ngay_qd_cap_td,cap_phe_duyet,so_hdtd,ngay_hdtd,so_tien_vnd,
      don_vi_hien_thi,dong_tien,ngay_het_han,muc_dich,linh_vuc_kd,nhu_cau_vld,thong_tin_bo_sung,quan_he_tctd,co_nkhlq,
      co_doi_tac_luu_y,khlq_ghi_chu,trang_thai_ho_so,ngay_lap,so_van_ban,ngay_tao,ngay_sua)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(...fileValues(customerId, f), now, now).lastInsertRowid);
  }

  function updateFile(id, customerId, f, now, version) {
    db.prepare(`UPDATE ho_so_cap_td SET id_khach_hang=?,so_qd_cap_td=?,ngay_qd_cap_td=?,cap_phe_duyet=?,so_hdtd=?,ngay_hdtd=?,so_tien_vnd=?,
      don_vi_hien_thi=?,dong_tien=?,ngay_het_han=?,muc_dich=?,linh_vuc_kd=?,nhu_cau_vld=?,thong_tin_bo_sung=?,quan_he_tctd=?,co_nkhlq=?,
      co_doi_tac_luu_y=?,khlq_ghi_chu=?,trang_thai_ho_so=?,ngay_lap=?,so_van_ban=?,version=version+1,ngay_sua=? WHERE id=? AND version=?`)
      .run(...fileValues(customerId, f), now, id, version);
  }

  function replaceChildren(fileId, customerId, payload) {
    db.prepare('DELETE FROM co_cau_von WHERE id_khach_hang=?').run(customerId);
    const capital = db.prepare('INSERT INTO co_cau_von(id_khach_hang,ten_thanh_vien,loai_thanh_vien,gia_tri_von_gop,ty_le_pct,thu_tu) VALUES(?,?,?,?,?,?)');
    payload.capitalMembers.forEach((x, i) => capital.run(customerId, x.name.trim(), nullable(x.type), num(x.contributedCapital), num(x.percentage), i + 1));

    db.prepare('DELETE FROM doi_tac_lien_quan WHERE id_ho_so=?').run(fileId);
    const partner = db.prepare('INSERT INTO doi_tac_lien_quan(id_ho_so,ten_doi_tac,cif_doi_tac,ma_so_thue,loai_quan_he,bien_phap_quan_ly,thu_tu) VALUES(?,?,?,?,?,?,?)');
    payload.relatedPartners.forEach((x, i) => partner.run(fileId, x.name.trim(), nullable(x.cif), nullable(x.taxCode), nullable(x.relationshipType), nullable(x.managementMeasure), i + 1));

    db.prepare('DELETE FROM dieu_kien WHERE id_ho_so=?').run(fileId);
    const conditionStmt = db.prepare(`INSERT INTO dieu_kien(id_ho_so,nhom_dk,loai_dk,thu_tu,noi_dung_dk,tan_suat,tinh_chat_dk,chi_tieu_dinh_luong,
      nguong_yeu_cau,ngay_bat_dau_theo_doi,ngay_ket_thuc_theo_doi) VALUES(?,?,?,?,?,?,?,?,?,?,?)`);
    const periodStmt = db.prepare(`INSERT INTO ky_theo_doi_dk(id_dieu_kien,ky_theo_doi,ngay_den_han,tinh_hinh_thuc_hien,gia_tri_thuc_te,
      ngay_ghi_nhan_gia_tri,nguoi_ghi_nhan,ngay_thuc_hien,tinh_trang,muc_dk_ghi_de,ly_do_ghi_de) VALUES(?,?,?,?,?,?,?,?,?,?,?)`);
    payload.conditions.forEach((x, i) => {
      const conditionId = Number(conditionStmt.run(fileId, x.group, x.type, i + 1, x.content.trim(), x.frequency, x.nature,
        nullable(x.quantitativeIndicator), numOrNull(x.threshold), nullable(x.monitoringStartDate), nullable(x.monitoringEndDate)).lastInsertRowid);
      x.periods.forEach(p => periodStmt.run(conditionId, p.code.trim(), nullable(p.dueDate), nullable(p.performance), numOrNull(p.actualValue),
        nullable(p.valueRecordedDate), nullable(p.recordedBy), nullable(p.completedDate), p.status, nullable(p.overrideLevel), nullable(p.overrideReason)));
    });

    db.prepare('DELETE FROM dieu_kien_no WHERE id_ho_so=?').run(fileId);
    const debt = db.prepare(`INSERT INTO dieu_kien_no(id_ho_so,stt,ngay_no,noi_dung,loai_ho_so_no,ngay_cam_ket_bs,ngay_bo_sung_hs,tinh_trang,muc_dieu_kien)
      VALUES(?,?,?,?,?,?,?,?,?)`);
    payload.debts.forEach((x, i) => debt.run(fileId, i + 1, x.debtDate, x.content.trim(), nullable(x.documentType), x.commitmentDate,
      nullable(x.supplementedDate), x.status, x.levelType));
  }

  function audit(fileId) {
    return db.prepare('SELECT * FROM nhat_ky_he_thong WHERE bang=? AND id_ban_ghi=? ORDER BY id DESC').all('ho_so_cap_td', fileId)
      .map(x => ({ id: x.id, at: x.thoi_diem, action: x.hanh_dong }));
  }

  function close() { db.close(); }
  return { list, config, get, save, audit, close, db };
}

function fileValues(customerId, f) {
  return [customerId, f.decisionNumber.trim(), f.decisionDate, f.approvalLevel, f.contractNumber.trim(), f.contractDate,
    num(f.creditAmountVnd), f.displayUnit || 'TRIEU', nullable(f.currency), f.expiryDate, f.purpose.trim(), f.businessField.trim(),
    numOrNull(f.workingCapitalNeed), nullable(f.additionalInfo), nullable(f.otherCreditInstitutions), bool(f.hasRelatedCustomerGroup),
    bool(f.hasManagedPartners), nullable(f.relatedGroupNotes), f.status || 'NHAP', f.reportDate, nullable(f.documentNumber)];
}

function validate(p) {
  const errors = [];
  if (!p || typeof p !== 'object') return ['Dữ liệu hồ sơ không hợp lệ.'];
  const c = p.customer || {}, f = p.file || {};
  const required = [[c.cif,'CIF'],[c.name,'Tên khách hàng'],[c.type,'Loại hình khách hàng'],[c.branchCode,'Mã chi nhánh'],[c.branchName,'Tên chi nhánh'],
    [f.decisionNumber,'Số quyết định'],[f.decisionDate,'Ngày quyết định'],[f.approvalLevel,'Cấp phê duyệt'],[f.contractNumber,'Số HĐTD'],
    [f.contractDate,'Ngày HĐTD'],[f.expiryDate,'Ngày hết hạn'],[f.purpose,'Mục đích cấp tín dụng'],[f.businessField,'Lĩnh vực kinh doanh'],[f.reportDate,'Ngày lập']];
  required.forEach(([value, label]) => { if (!String(value || '').trim()) errors.push(`${label} là bắt buộc.`); });
  if (!/^\d{3,20}$/.test(String(c.cif || '').trim())) errors.push('CIF phải gồm 3–20 chữ số.');
  if (!(Number(f.creditAmountVnd) > 0)) errors.push('Số tiền cấp tín dụng phải lớn hơn 0.');
  if (!Array.isArray(p.capitalMembers) || !Array.isArray(p.relatedPartners) || !Array.isArray(p.conditions) || !Array.isArray(p.debts)) errors.push('Danh sách dữ liệu liên quan không hợp lệ.');
  (p.capitalMembers || []).forEach((x,i) => { if (!String(x.name||'').trim()) errors.push(`Cơ cấu vốn dòng ${i+1}: thiếu tên thành viên.`); });
  (p.relatedPartners || []).forEach((x,i) => { if (!String(x.name||'').trim()) errors.push(`Đối tác dòng ${i+1}: thiếu tên đối tác.`); });
  (p.conditions || []).forEach((x,i) => {
    if (!String(x.content||'').trim()) errors.push(`Điều kiện dòng ${i+1}: thiếu nội dung.`);
    if (!['TSBD','DKTD'].includes(x.group)) errors.push(`Điều kiện dòng ${i+1}: nhóm không hợp lệ.`);
    (x.periods || []).forEach((p,j) => { if (!String(p.code||'').trim()) errors.push(`Điều kiện ${i+1}, kỳ ${j+1}: thiếu mã kỳ.`); });
  });
  (p.debts || []).forEach((x,i) => { if (!x.debtDate || !String(x.content||'').trim() || !x.commitmentDate) errors.push(`Điều kiện nợ dòng ${i+1}: thiếu ngày nợ, nội dung hoặc ngày cam kết.`); });
  return errors;
}

function mapCustomer(r) { return { id:r.customer_id,cif:r.cif,name:r.ten_khach_hang,type:r.loai_hinh_kh,businessRegistration:r.so_gcn_dkkd||'',businessRegistrationDate:r.ngay_cap_dkkd||'',taxCode:r.ma_so_thue||'',rating:r.xhtd_hang||'',ratingDate:r.xhtd_ky||'',legalRepresentative:r.nguoi_dai_dien_pl||'',authorizedPerson:r.nguoi_duoc_uy_quyen||'',chiefAccountant:r.ke_toan_truong||'',notes:r.luu_y_khac||'',branchCode:r.ma_chi_nhanh,branchName:r.ten_chi_nhanh,source:'MANUAL' }; }
function mapFile(r) { return { code:r.ma_ho_so,decisionNumber:r.so_qd_cap_td,decisionDate:r.ngay_qd_cap_td,approvalLevel:r.cap_phe_duyet,contractNumber:r.so_hdtd,contractDate:r.ngay_hdtd,creditAmountVnd:Number(r.so_tien_vnd),displayUnit:r.don_vi_hien_thi,currency:r.dong_tien||'',expiryDate:r.ngay_het_han,purpose:r.muc_dich,businessField:r.linh_vuc_kd,workingCapitalNeed:r.nhu_cau_vld==null?'':Number(r.nhu_cau_vld),additionalInfo:r.thong_tin_bo_sung||'',otherCreditInstitutions:r.quan_he_tctd||'',hasRelatedCustomerGroup:!!r.co_nkhlq,hasManagedPartners:!!r.co_doi_tac_luu_y,relatedGroupNotes:r.khlq_ghi_chu||'',status:r.trang_thai_ho_so,reportDate:r.ngay_lap,documentNumber:r.so_van_ban||'',source:'MANUAL',createdAt:r.file_created_at,updatedAt:r.file_updated_at}; }
function mapCapital(r){return{id:r.id,name:r.ten_thanh_vien,type:r.loai_thanh_vien||'',contributedCapital:Number(r.gia_tri_von_gop),percentage:Number(r.ty_le_pct),source:'MANUAL'};}
function mapPartner(r){return{id:r.id,name:r.ten_doi_tac,cif:r.cif_doi_tac||'',taxCode:r.ma_so_thue||'',relationshipType:r.loai_quan_he||'',managementMeasure:r.bien_phap_quan_ly||'',source:'MANUAL'};}
function mapCondition(r){return{id:r.id,group:r.nhom_dk,type:r.loai_dk,content:r.noi_dung_dk,frequency:r.tan_suat,nature:r.tinh_chat_dk,quantitativeIndicator:r.chi_tieu_dinh_luong||'',threshold:r.nguong_yeu_cau==null?'':Number(r.nguong_yeu_cau),monitoringStartDate:r.ngay_bat_dau_theo_doi||'',monitoringEndDate:r.ngay_ket_thuc_theo_doi||'',source:'MANUAL'};}
function mapPeriod(r){return{id:r.id,code:r.ky_theo_doi,dueDate:r.ngay_den_han||'',performance:r.tinh_hinh_thuc_hien||'',actualValue:r.gia_tri_thuc_te==null?'':Number(r.gia_tri_thuc_te),valueRecordedDate:r.ngay_ghi_nhan_gia_tri||'',recordedBy:r.nguoi_ghi_nhan||'',completedDate:r.ngay_thuc_hien||'',status:r.tinh_trang,overrideLevel:r.muc_dk_ghi_de||'',overrideReason:r.ly_do_ghi_de||'',source:'MANUAL'};}
function mapDebt(r){return{id:r.id,debtDate:r.ngay_no,content:r.noi_dung,documentType:r.loai_ho_so_no||'',commitmentDate:r.ngay_cam_ket_bs,supplementedDate:r.ngay_bo_sung_hs||'',status:r.tinh_trang,levelType:r.muc_dieu_kien,source:'MANUAL'};}
function nullable(v){return v === undefined || v === null || String(v).trim()==='' ? null : String(v).trim();}
function num(v){return Number(v)||0;}
function numOrNull(v){return v === '' || v === null || v === undefined ? null : Number(v);}
function bool(v){return v ? 1 : 0;}
function cleanCode(v){return String(v||'CN').replace(/[^A-Za-z0-9]/g,'').slice(0,10)||'CN';}
function httpError(status,message){const e=new Error(message);e.status=status;return e;}

module.exports = { createStore, validate };
