'use strict';

const $ = s => document.querySelector(s);
const today = new Date().toISOString().slice(0,10);
let config = {};
let state;

document.addEventListener('DOMContentLoaded', async () => {
  try { config = await api('/api/config'); }
  catch (error) { return toast(`Không tải được danh mục cấu hình.\n${error.message}`, true); }
  state = blankRecord();
  $('#evaluationDate').value = today;
  $('#homeBtn').onclick = showList;
  $('#newBtn').onclick = openNew;
  $('[data-new]').onclick = openNew;
  $('#searchBtn').onclick = loadList;
  $('#searchInput').onkeydown = e => { if (e.key === 'Enter') loadList(); };
  $('#saveBtn').onclick = saveRecord;
  $('#printBtn').onclick = () => window.print();
  $('#evaluationDate').onchange = renderScores;
  $('#n1').onchange = renderScores;
  $('#n2').onchange = renderScores;
  $('#recordForm').addEventListener('input', handleInput);
  $('#recordForm').addEventListener('change', handleInput);
  $('#recordForm').addEventListener('click', handleAction);
  loadList();
});

function blankRecord(){ return {
  id:null,version:0,
  customer:{cif:'',name:'',type:defaultValue('LOAI_HINH_KH'),businessRegistration:'',businessRegistrationDate:'',taxCode:'',rating:'',ratingDate:'',legalRepresentative:'',authorizedPerson:'',chiefAccountant:'',notes:'',branchCode:'',branchName:'',source:'MANUAL'},
  file:{code:'',decisionNumber:'',decisionDate:'',approvalLevel:defaultValue('CAP_PHE_DUYET'),contractNumber:'',contractDate:'',creditAmountVnd:'',displayUnit:defaultValue('DON_VI_HIEN_THI'),currency:defaultValue('DONG_TIEN'),expiryDate:'',purpose:'',businessField:'',workingCapitalNeed:'',additionalInfo:'',otherCreditInstitutions:'',hasRelatedCustomerGroup:false,hasManagedPartners:false,relatedGroupNotes:'',status:defaultValue('TRANG_THAI_HO_SO'),reportDate:today,documentNumber:'',source:'MANUAL'},
  capitalMembers:[],relatedPartners:[],conditions:[],debts:[]
}; }

async function loadList(){
  try{
    const rows = await api(`/api/files?q=${encodeURIComponent($('#searchInput').value)}`);
    $('#recordList').innerHTML = rows.length ? rows.map(r => `<article class="record-row" data-id="${r.id}">
      <div><span class="code">${esc(r.code)}</span><small>${esc(r.contractNumber)}</small></div>
      <div><b>${esc(r.customerName)}</b><small>CIF ${esc(r.cif)} · ${esc(r.branchCode)} — ${esc(r.branchName)}</small></div>
      <div><b>${money(r.creditAmount)} ₫</b><small>Hạn mức</small></div><div><b>${statusName(r.status)}</b><small>Cập nhật ${dateTime(r.updatedAt)}</small></div><div><button class="btn small">Mở hồ sơ</button></div>
    </article>`).join('') : '<div class="empty"><b>Chưa có hồ sơ nào</b><br>Tạo hồ sơ đầu tiên để bắt đầu nhập liệu.</div>';
    document.querySelectorAll('.record-row').forEach(x => x.onclick = () => openRecord(x.dataset.id));
  }catch(e){ toast(e.message,true); }
}

function showList(){ $('#editorView').classList.add('hidden');$('#listView').classList.remove('hidden');loadList();scrollTo(0,0); }
function openNew(){ state=blankRecord();showEditor(); }
async function openRecord(id){ try{state=await api(`/api/files/${id}`);showEditor();loadAudit();}catch(e){toast(e.message,true);} }
function showEditor(){ $('#listView').classList.add('hidden');$('#editorView').classList.remove('hidden');renderAll();scrollTo(0,0); }

function renderAll(){
  $('#editorEyebrow').textContent=state.file.code||'Hồ sơ mới';
  $('#editorTitle').textContent=state.customer.name||'Nhập hồ sơ QTTD';
  $('#editorMeta').textContent=state.id?`Phiên bản ${state.version} · lưu lần cuối ${dateTime(state.file.updatedAt)}`:'Mọi thông tin đều do người dùng nhập thủ công.';
  renderCustomer();renderCredit();renderConditions();renderDebts();renderScores();
}

function renderCustomer(){
  const c=state.customer;
  $('#customerSection').innerHTML=`${head('I','Thông tin khách hàng')}
  <div class="panel-body"><div class="form-grid">
    ${field('customer.name','Tên khách hàng',c.name,'text',6,true)}${field('customer.cif','CIF',c.cif,'text',2,true)}${selectField('customer.type','Loại hình',c.type,options('LOAI_HINH_KH'),2,true)}${field('customer.taxCode','Mã số thuế',c.taxCode,'text',2)}
    ${field('customer.businessRegistration','GCN ĐKKD',c.businessRegistration,'text',4)}${field('customer.businessRegistrationDate','Ngày cấp ĐKKD',c.businessRegistrationDate,'date',2)}${field('customer.branchCode','Mã chi nhánh',c.branchCode,'text',2,true)}${field('customer.branchName','Tên chi nhánh',c.branchName,'text',4,true)}
    ${field('customer.rating','Xếp hạng tín dụng',c.rating,'text',2)}${field('customer.ratingDate','Kỳ xếp hạng',c.ratingDate,'date',2)}${field('customer.legalRepresentative','Người đại diện pháp luật',c.legalRepresentative,'text',3)}${field('customer.authorizedPerson','Người được ủy quyền',c.authorizedPerson,'text',3)}${field('customer.chiefAccountant','Kế toán trưởng',c.chiefAccountant,'text',2)}
    ${field('customer.notes','Lưu ý khác',c.notes,'textarea',12)}
  </div>
  ${subhead('Cơ cấu vốn', 'add-capital', '+ Thêm thành viên')}
  <div class="table-wrap"><table><thead><tr><th>TT</th><th>Tên thành viên</th><th>Loại</th><th>Giá trị vốn góp (VND)</th><th>Tỷ lệ %</th><th></th></tr></thead><tbody>
  ${state.capitalMembers.length?state.capitalMembers.map((x,i)=>`<tr><td>${i+1}</td><td>${cell(`capitalMembers.${i}.name`,x.name)}</td><td>${cell(`capitalMembers.${i}.type`,x.type)}</td><td>${cell(`capitalMembers.${i}.contributedCapital`,x.contributedCapital,'number')}</td><td>${cell(`capitalMembers.${i}.percentage`,x.percentage,'number')}</td><td class="row-actions">${remove('capital',i)}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">Chưa có thành viên góp vốn.</td></tr>'}
  </tbody></table></div><p class="total-note ${capitalPercent()>100?'bad':''}">Tổng tỷ lệ: <b>${capitalPercent()}%</b> · Tổng vốn góp: <b>${money(state.capitalMembers.reduce((a,x)=>a+(+x.contributedCapital||0),0))} ₫</b></p></div>`;
}

function renderCredit(){const f=state.file;
  $('#creditSection').innerHTML=`${head('II','Thông tin cấp tín dụng')}<div class="panel-body"><div class="form-grid">
    ${field('file.documentNumber','Số văn bản',f.documentNumber,'text',2)}${field('file.reportDate','Ngày lập',f.reportDate,'date',2,true)}${selectField('file.status','Trạng thái hồ sơ',f.status,options('TRANG_THAI_HO_SO'),2,true)}${field('file.decisionNumber','Số quyết định cấp TD',f.decisionNumber,'text',4,true)}${field('file.decisionDate','Ngày quyết định',f.decisionDate,'date',2,true)}
    ${selectField('file.approvalLevel','Cấp phê duyệt',f.approvalLevel,options('CAP_PHE_DUYET'),3,true)}${field('file.contractNumber','Số HĐTD',f.contractNumber,'text',3,true)}${field('file.contractDate','Ngày HĐTD',f.contractDate,'date',2,true)}${field('file.expiryDate','Thời hạn đến ngày',f.expiryDate,'date',2,true)}${selectField('file.currency','Đồng tiền',f.currency,options('DONG_TIEN'),2)}
    ${field('file.creditAmountVnd','Số tiền cấp tín dụng (VND nguyên tệ)',f.creditAmountVnd,'number',4,true)}${selectField('file.displayUnit','Đơn vị hiển thị',f.displayUnit,options('DON_VI_HIEN_THI'),2)}${field('file.workingCapitalNeed','Nhu cầu VLĐ (VND)',f.workingCapitalNeed,'number',3)}${field('file.businessField','Lĩnh vực kinh doanh',f.businessField,'text',3,true)}
    ${field('file.purpose','Mục đích cấp tín dụng',f.purpose,'textarea',6,true)}${field('file.additionalInfo','Thông tin bổ sung',f.additionalInfo,'textarea',6)}${field('file.otherCreditInstitutions','Quan hệ tại các TCTD',f.otherCreditInstitutions,'textarea',12)}
    ${selectField('file.hasRelatedCustomerGroup','Thuộc nhóm KHLQ',String(!!f.hasRelatedCustomerGroup),options('CO_KHONG'),2)}${selectField('file.hasManagedPartners','Có đối tác cần quản lý',String(!!f.hasManagedPartners),options('CO_KHONG'),2)}${field('file.relatedGroupNotes','Biện pháp quản lý chung',f.relatedGroupNotes,'text',8)}
  </div>${subhead('Đối tác liên quan','add-partner','+ Thêm đối tác')}
  <div class="table-wrap"><table><thead><tr><th>TT</th><th>Tên đối tác</th><th>CIF</th><th>MST</th><th>Loại quan hệ</th><th>Biện pháp quản lý</th><th></th></tr></thead><tbody>
  ${state.relatedPartners.length?state.relatedPartners.map((x,i)=>`<tr><td>${i+1}</td><td>${cell(`relatedPartners.${i}.name`,x.name)}</td><td>${cell(`relatedPartners.${i}.cif`,x.cif)}</td><td>${cell(`relatedPartners.${i}.taxCode`,x.taxCode)}</td><td>${cell(`relatedPartners.${i}.relationshipType`,x.relationshipType)}</td><td>${cell(`relatedPartners.${i}.managementMeasure`,x.managementMeasure)}</td><td>${remove('partner',i)}</td></tr>`).join(''):'<tr><td colspan="7" class="empty">Chưa có đối tác liên quan.</td></tr>'}
  </tbody></table></div></div>`;
}

function renderConditions(){
  const groups=[['TSBD','III.a — Tài sản bảo đảm'],['DKTD','III.b — Điều kiện tín dụng']];
  $('#conditionSection').innerHTML=`${head('III','Tài sản bảo đảm & Điều kiện tín dụng')}<div class="panel-body">
  ${groups.map(([group,title])=>`${subhead(title,`add-condition:${group}`,'+ Thêm điều kiện')}${state.conditions.map((x,i)=>({x,i})).filter(o=>o.x.group===group).map(({x,i})=>conditionCard(x,i)).join('')||'<div class="empty">Chưa có điều kiện.</div>'}`).join('')}
  </div>`;
}

function conditionCard(x,i){return `<article class="condition"><div class="condition-title"><span class="tag">${esc(x.group)}</span><b>Điều kiện ${i+1}</b><span class="grow"></span><button type="button" class="btn small" data-action="add-period" data-index="${i}">+ Kỳ theo dõi</button>${remove('condition',i)}</div><div class="condition-body"><div class="form-grid">
  ${selectField(`conditions.${i}.type`,'Loại điều kiện',x.type,options(x.group==='TSBD'?'LOAI_DK_TSBD':'LOAI_DK_DKTD'),2,true)}${selectField(`conditions.${i}.frequency`,'Tần suất',x.frequency,options('TAN_SUAT'),2,true)}${selectField(`conditions.${i}.nature`,'Tính chất',x.nature,options('TINH_CHAT_DK'),2,true)}${selectField(`conditions.${i}.quantitativeIndicator`,'Chỉ tiêu định lượng',x.quantitativeIndicator,options('CHI_TIEU_DINH_LUONG'),3)}${field(`conditions.${i}.threshold`,'Ngưỡng yêu cầu',x.threshold,'number',3)}
  ${field(`conditions.${i}.monitoringStartDate`,'Bắt đầu theo dõi',x.monitoringStartDate,'date',2)}${field(`conditions.${i}.monitoringEndDate`,'Kết thúc theo dõi',x.monitoringEndDate,'date',2)}${field(`conditions.${i}.content`,'Nội dung điều kiện',x.content,'textarea',8,true)}
  </div><div class="table-wrap periods"><table><thead><tr><th>Kỳ</th><th>Đến hạn</th><th>Tình hình thực hiện</th><th>Giá trị</th><th>Ngày ghi nhận</th><th>Người ghi nhận</th><th>Ngày thực hiện</th><th>Tình trạng</th><th>Ghi đè</th><th>Mức tự động</th><th></th></tr></thead><tbody>
  ${x.periods.length?x.periods.map((p,j)=>periodRow(x,i,p,j)).join(''):'<tr><td colspan="11" class="empty">Chưa có kỳ theo dõi.</td></tr>'}
  </tbody></table></div></div></article>`;}

function periodRow(condition,i,p,j){const score=scoreCondition(condition,p);return `<tr><td>${cell(`conditions.${i}.periods.${j}.code`,p.code)}</td><td>${cell(`conditions.${i}.periods.${j}.dueDate`,p.dueDate,'date')}</td><td>${cell(`conditions.${i}.periods.${j}.performance`,p.performance,'textarea')}</td><td>${cell(`conditions.${i}.periods.${j}.actualValue`,p.actualValue,'number')}</td><td>${cell(`conditions.${i}.periods.${j}.valueRecordedDate`,p.valueRecordedDate,'date')}</td><td>${cell(`conditions.${i}.periods.${j}.recordedBy`,p.recordedBy)}</td><td>${cell(`conditions.${i}.periods.${j}.completedDate`,p.completedDate,'date')}</td><td>${cellSelect(`conditions.${i}.periods.${j}.status`,p.status,options('TINH_TRANG_KY'))}</td><td>${cellSelect(`conditions.${i}.periods.${j}.overrideLevel`,p.overrideLevel,options('MUC_GHI_DE'))}${cell(`conditions.${i}.periods.${j}.overrideReason`,p.overrideReason)}</td><td class="status-cell">${scoreHtml(score)}</td><td>${remove('period',j,` data-parent="${i}"`)}</td></tr>`;}

function renderDebts(){
  $('#debtSection').innerHTML=`${head('IV','Điều kiện theo dõi & Điều kiện nợ','add-debt','+ Thêm dòng')}<div class="panel-body"><div class="table-wrap"><table><thead><tr><th>STT</th><th>Ngày nợ</th><th>Nội dung</th><th>Loại hồ sơ</th><th>Ngày cam kết BS</th><th>Ngày bổ sung HS</th><th>Tình trạng</th><th>Mức điều kiện</th><th>Kết luận tự động</th><th></th></tr></thead><tbody>
  ${state.debts.length?state.debts.map((x,i)=>`<tr><td>${i+1}</td><td>${cell(`debts.${i}.debtDate`,x.debtDate,'date')}</td><td>${cell(`debts.${i}.content`,x.content,'textarea')}</td><td>${cell(`debts.${i}.documentType`,x.documentType)}</td><td>${cell(`debts.${i}.commitmentDate`,x.commitmentDate,'date')}</td><td>${cell(`debts.${i}.supplementedDate`,x.supplementedDate,'date')}</td><td>${cellSelect(`debts.${i}.status`,x.status,options('TINH_TRANG_NO'))}</td><td>${cellSelect(`debts.${i}.levelType`,x.levelType,options('MUC_DIEU_KIEN'))}</td><td class="status-cell">${scoreHtml(scoreDebt(x))}</td><td>${remove('debt',i)}</td></tr>`).join(''):'<tr><td colspan="10" class="empty">Chưa có điều kiện nợ.</td></tr>'}
  </tbody></table></div></div>`;
}

function handleInput(e){const path=e.target.dataset.path;if(!path)return;let value=e.target.type==='checkbox'?e.target.checked:e.target.value;if(path==='file.hasRelatedCustomerGroup'||path==='file.hasManagedPartners')value=value==='true';setPath(state,path,value);const affectsScore=path.includes('.status')||path.includes('Date')||path.includes('threshold')||path.includes('actualValue')||path.includes('nature')||path.includes('override');if(affectsScore){renderScores();if(e.type==='change'){renderConditions();renderDebts();renderScores();}}}
function handleAction(e){const b=e.target.closest('[data-action]');if(!b)return;e.preventDefault();const [action,arg]=b.dataset.action.split(':');const i=Number(b.dataset.index);if(action==='add-capital')state.capitalMembers.push({name:'',type:'Cá nhân',contributedCapital:'',percentage:'',source:'MANUAL'});if(action==='remove-capital')state.capitalMembers.splice(i,1);if(action==='add-partner')state.relatedPartners.push({name:'',cif:'',taxCode:'',relationshipType:'Quan hệ thương mại',managementMeasure:'',source:'MANUAL'});if(action==='remove-partner')state.relatedPartners.splice(i,1);if(action==='add-condition'){const typeGroup=arg==='TSBD'?'LOAI_DK_TSBD':'LOAI_DK_DKTD';state.conditions.push({group:arg,type:defaultValue(typeGroup),content:'',frequency:defaultValue('TAN_SUAT'),nature:defaultValue('TINH_CHAT_DK'),quantitativeIndicator:defaultValue('CHI_TIEU_DINH_LUONG'),threshold:'',monitoringStartDate:'',monitoringEndDate:'',periods:[],source:'MANUAL'});}if(action==='remove-condition')state.conditions.splice(i,1);if(action==='add-period')state.conditions[i].periods.push({code:'',dueDate:'',performance:'',actualValue:'',valueRecordedDate:'',recordedBy:'',completedDate:'',status:defaultValue('TINH_TRANG_KY'),overrideLevel:defaultValue('MUC_GHI_DE'),overrideReason:'',source:'MANUAL'});if(action==='remove-period')state.conditions[Number(b.dataset.parent)].periods.splice(i,1);if(action==='add-debt')state.debts.push({debtDate:today,content:'',documentType:'',commitmentDate:'',supplementedDate:'',status:defaultValue('TINH_TRANG_NO'),levelType:defaultValue('MUC_DIEU_KIEN'),source:'MANUAL'});if(action==='remove-debt')state.debts.splice(i,1);renderAll();}

async function saveRecord(){
  $('#saveBtn').disabled=true;
  try{const saved=await api(state.id?`/api/files/${state.id}`:'/api/files',{method:state.id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(state)});state=saved;renderAll();loadAudit();toast(`Đã lưu ${saved.file.code} vào SQLite local.`);}
  catch(e){toast(e.message,true);}finally{$('#saveBtn').disabled=false;}
}
async function loadAudit(){if(!state.id)return;try{const rows=await api(`/api/files/${state.id}/audit`);$('#auditSection').classList.remove('hidden');$('#auditSection').innerHTML=`${head('V','Nhật ký lưu hồ sơ')}<div class="panel-body">${rows.map(x=>`<div><span class="code">${dateTime(x.at)}</span> — ${x.action==='TAO'?'Tạo hồ sơ':'Cập nhật hồ sơ'}</div>`).join('')}</div>`;}catch{}}

function scoreCondition(c,p){
  const n1=+$('#n1').value||15,n2=+$('#n2').value||30,evalDate=$('#evaluationDate').value||today;
  if(!p)return {level:'X',reason:'Chưa phát sinh kỳ theo dõi'};if(p.overrideLevel)return{level:p.overrideLevel,reason:`Ghi đè thủ công: ${p.overrideReason||'không nêu lý do'}`};if(p.status==='MIEN_GIAM')return{level:'X',reason:'Được miễn giảm'};
  if(c.quantitativeIndicator&&p.actualValue!==''&&c.threshold!==''){const a=+p.actualValue,t=+c.threshold;if(a>=t)return{level:'X',reason:`Giá trị ${a} đạt ngưỡng ${t}`};if(a>=t*.95)return{level:'V',reason:`Giá trị ${a} gần ngưỡng ${t}`};return{level:'D',reason:`Giá trị ${a} dưới ngưỡng ${t}`};}
  if(p.status==='DA_THUC_HIEN'){const delay=p.completedDate&&p.dueDate?day(p.completedDate)-day(p.dueDate):0;if(delay<=0)return{level:'X',reason:'Đã thực hiện đúng hạn'};if(c.nature!=='TIEN_QUYET'&&delay<=n2)return{level:'V',reason:`Hoàn thành chậm ${delay} ngày`};return{level:'D',reason:`Hoàn thành chậm ${delay} ngày`};}
  if(!p.dueDate)return{level:'X',reason:'Chưa có ngày đến hạn'};const remaining=day(p.dueDate)-day(evalDate);if(remaining>=0)return remaining<=n1?{level:'V',reason:`Còn ${remaining} ngày đến hạn`}:{level:'X',reason:`Còn ${remaining} ngày đến hạn`};const overdue=Math.abs(remaining);return c.nature!=='TIEN_QUYET'&&overdue<=n2?{level:'V',reason:`Quá hạn ${overdue} ngày`}:{level:'D',reason:`Quá hạn ${overdue} ngày`};
}
function scoreDebt(x){const n1=+$('#n1').value||15,n2=+$('#n2').value||30,evalDate=$('#evaluationDate').value||today,pre=x.levelType==='TIEN_QUYET';if(x.supplementedDate){const delay=day(x.supplementedDate)-day(x.commitmentDate);if(delay<=0)return{level:'X',reason:'Đã bổ sung đúng hạn'};return !pre&&delay<=n2?{level:'V',reason:`Bổ sung chậm ${delay} ngày`}:{level:'D',reason:`Bổ sung chậm ${delay} ngày`};}if(!x.commitmentDate)return{level:'X',reason:'Chưa có ngày cam kết'};const r=day(x.commitmentDate)-day(evalDate);if(r>=0)return r<=n1?{level:'V',reason:`Còn ${r} ngày đến hạn`}:{level:'X',reason:`Còn ${r} ngày đến hạn`};const o=Math.abs(r);return !pre&&o<=n2?{level:'V',reason:`Quá hạn ${o} ngày`}:{level:'D',reason:`Quá hạn ${o} ngày`};}
function renderScores(){const scores=state.conditions.map(x=>scoreCondition(x,x.periods.at(-1))).concat(state.debts.map(scoreDebt));const level=scores.some(x=>x.level==='D')?'D':scores.some(x=>x.level==='V')?'V':'X';const el=$('#overallScore');el.className=`score ${level}`;el.textContent={X:'Xanh',V:'Vàng',D:'Đỏ'}[level];}

function head(no,title,action,label){return `<header class="panel-head"><span>${no}</span><h2>${title}</h2>${action?`<div class="actions"><button type="button" class="btn light small" data-action="${action}">${label}</button></div>`:''}</header>`;}
function subhead(title,action,label){return `<div class="subhead"><h3>${title}</h3><button type="button" class="btn small" data-action="${action}">${label}</button></div>`;}
function field(path,label,value,type='text',span=3,required=false){const content=type==='textarea'?`<textarea aria-label="${esc(label)}" data-path="${path}">${esc(value)}</textarea>`:`<input aria-label="${esc(label)}" data-path="${path}" type="${type}" value="${esc(value)}" ${type==='number'?'step="any"':''}>`;return `<div class="field c${span}"><label class="${required?'required':''}">${label}</label>${content}<div class="manual">Nhập thủ công</div></div>`;}
function selectField(path,label,value,items,span=3,required=false){return `<div class="field c${span}"><label class="${required?'required':''}">${label}</label><select aria-label="${esc(label)}" data-path="${path}">${optionHtml(items,value)}</select><div class="manual">Lấy từ bảng danh_muc</div></div>`;}
function cell(path,value,type='text'){const label=path.split('.').at(-1);return type==='textarea'?`<textarea aria-label="${esc(label)}" data-path="${path}">${esc(value)}</textarea>`:`<input aria-label="${esc(label)}" data-path="${path}" type="${type}" value="${esc(value)}" ${type==='number'?'step="any"':''}>`;}
function cellSelect(path,value,items){return `<select aria-label="${esc(path.split('.').at(-1))}" data-path="${path}">${optionHtml(items,value)}</select>`;}
function remove(type,index,extra=''){return `<button type="button" class="btn danger small" data-action="remove-${type}" data-index="${index}"${extra}>Xóa</button>`;}
function scoreHtml(s){return `<span class="score ${s.level}">${{X:'Xanh',V:'Vàng',D:'Đỏ'}[s.level]}</span><div class="reason">${esc(s.reason)}</div>`;}
function setPath(obj,path,value){const keys=path.split('.');const last=keys.pop();const target=keys.reduce((o,k)=>o[k],obj);target[last]=value;}
function capitalPercent(){return Math.round(state.capitalMembers.reduce((a,x)=>a+(+x.percentage||0),0)*100)/100;}
function day(s){return Date.parse(`${s}T00:00:00Z`)/86400000;}
function money(v){return new Intl.NumberFormat('vi-VN',{maximumFractionDigits:2}).format(Number(v)||0);}
function dateTime(v){return v?new Date(v).toLocaleString('vi-VN'):'—';}
function options(type){return config[type]||[];}
function defaultValue(type){const items=options(type);return (items.find(x=>x.isDefault)||items[0]||{}).value||'';}
function optionLabel(type,value){return options(type).find(x=>String(x.value)===String(value))?.label||value;}
function optionHtml(items,value){return items.map(x=>`<option value="${esc(x.value)}" ${String(value)===String(x.value)?'selected':''}>${esc(x.label)}</option>`).join('');}
function statusName(v){return optionLabel('TRANG_THAI_HO_SO',v);}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function api(url,options){const r=await fetch(url,options);const data=await r.json();if(!r.ok){const details=data.details?.join('\n');throw new Error(details||data.error||'Có lỗi xảy ra.');}return data;}
let toastTimer;function toast(message,error=false){const el=$('#toast');el.textContent=message;el.className=`toast${error?' error':''}`;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),5000);}
