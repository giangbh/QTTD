'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createStore } = require('../db');

function payload(contract='HDTD-001') { return {
  version:0,
  customer:{cif:'68735',name:'Khách hàng thử nghiệm',type:'HO_KINH_DOANH',branchCode:'147',branchName:'Ba Tháng Hai'},
  file:{decisionNumber:'QD-001',decisionDate:'2026-08-01',approvalLevel:'GIAM_DOC_CAP_1',contractNumber:contract,contractDate:'2026-08-02',creditAmountVnd:73000000000,displayUnit:'TY',currency:'VND',expiryDate:'2027-08-01',purpose:'Bổ sung vốn lưu động',businessField:'Đại lý vé số',reportDate:'2026-08-21',status:'NHAP'},
  capitalMembers:[{name:'Trần Ngọc Tâm',type:'Cá nhân',contributedCapital:1000000000,percentage:100}],
  relatedPartners:[{name:'Đối tác A',relationshipType:'Thương mại',managementMeasure:'Theo dõi dòng tiền'}],
  conditions:[{group:'TSBD',type:'BPBD',content:'Duy trì tỷ lệ TSBĐ/HMTD tối thiểu 100%',frequency:'QUY',nature:'THEO_DOI',quantitativeIndicator:'TSBD_HMTD',threshold:100,periods:[{code:'2026-Q3',dueDate:'2026-09-30',performance:'Đạt 106%',actualValue:106,valueRecordedDate:'2026-08-20',recordedBy:'CB QTTD',completedDate:'2026-08-20',status:'DA_THUC_HIEN'}]}],
  debts:[{debtDate:'2026-08-01',content:'Bổ sung bảo hiểm',documentType:'Bảo hiểm',commitmentDate:'2026-08-31',supplementedDate:'',status:'CHUA_DEN_HAN',levelType:'THEO_DOI'}]
}; }

test('lưu và đọc lại toàn bộ hồ sơ cùng dữ liệu liên quan', t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qttd-test-'));
  const store = createStore(path.join(dir, 'test.db'));
  t.after(() => { store.close(); fs.rmSync(dir,{recursive:true,force:true}); });
  const saved = store.save(payload());
  assert.match(saved.file.code, /^QTTD-147-2026-/);
  assert.equal(saved.customer.cif, '68735');
  assert.equal(saved.capitalMembers.length, 1);
  assert.equal(saved.relatedPartners.length, 1);
  assert.equal(saved.conditions[0].periods[0].actualValue, 106);
  assert.equal(saved.debts[0].content, 'Bổ sung bảo hiểm');
  assert.equal(store.list('68735').length, 1);
  assert.equal(store.audit(saved.id).length, 1);
  assert.deepEqual(store.config().TRANG_THAI_HO_SO.map(x => x.value), ['NHAP','HIEU_LUC','DONG']);
  assert.equal(store.config().CAP_PHE_DUYET.find(x => x.isDefault).value, 'GIAM_DOC_CAP_1');
});

test('chặn trùng số HĐTD và kiểm soát phiên bản', t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qttd-test-'));
  const store = createStore(path.join(dir, 'test.db'));
  t.after(() => { store.close(); fs.rmSync(dir,{recursive:true,force:true}); });
  const first = store.save(payload());
  const duplicate = payload(); duplicate.customer.cif='99999';
  assert.throws(() => store.save(duplicate), /Số HĐTD đã tồn tại/);
  const stale = structuredClone(first); stale.version=0; stale.file.purpose='Thay đổi';
  const updated = store.save(first, first.id);
  assert.equal(updated.version, 1);
  assert.throws(() => store.save(stale, first.id), /phiên khác/);
});
