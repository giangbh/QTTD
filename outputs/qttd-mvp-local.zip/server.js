'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { createStore } = require('./db');

const PORT = Number(process.env.PORT || 8080);
const DATA_PATH = process.env.QTTD_DB_PATH || path.join(__dirname, 'data', 'qttd.db');
const store = createStore(DATA_PATH);
const PUBLIC = path.join(__dirname, 'public');

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname === '/api/health' && req.method === 'GET') return json(res, 200, { ok:true, database:DATA_PATH });
    if (url.pathname === '/api/config' && req.method === 'GET') return json(res, 200, store.config());
    if (url.pathname === '/api/files' && req.method === 'GET') return json(res, 200, store.list(url.searchParams.get('q') || ''));
    if (url.pathname === '/api/files' && req.method === 'POST') return save(req, res, null);
    const match = url.pathname.match(/^\/api\/files\/(\d+)(\/audit)?$/);
    if (match && req.method === 'GET') {
      if (match[2]) return json(res, 200, store.audit(Number(match[1])));
      const record = store.get(Number(match[1]));
      return record ? json(res, 200, record) : json(res, 404, { error:'Không tìm thấy hồ sơ.' });
    }
    if (match && !match[2] && req.method === 'PUT') return save(req, res, Number(match[1]));
    if (url.pathname.startsWith('/api/')) return json(res, 404, { error:'API không tồn tại.' });
    return staticFile(url.pathname, res);
  } catch (error) {
    console.error(error);
    return json(res, error.status || 500, { error:error.message || 'Lỗi hệ thống.' });
  }
});

async function save(req, res, id) {
  const payload = await readJson(req);
  const result = store.save(payload, id);
  if (result.validationErrors) return json(res, 422, { error:'Dữ liệu chưa hợp lệ.', details:result.validationErrors });
  return json(res, id ? 200 : 201, result);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 5_000_000) reject(Object.assign(new Error('Dữ liệu gửi lên quá lớn.'), { status:413 }));
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); }
      catch { reject(Object.assign(new Error('JSON không hợp lệ.'), { status:400 })); }
    });
    req.on('error', reject);
  });
}

function staticFile(urlPath, res) {
  const requested = urlPath === '/' ? 'index.html' : decodeURIComponent(urlPath.slice(1));
  const filePath = path.resolve(PUBLIC, requested);
  if (!filePath.startsWith(`${PUBLIC}${path.sep}`) && filePath !== path.join(PUBLIC, 'index.html')) return json(res, 403, { error:'Từ chối truy cập.' });
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return json(res, 404, { error:'Không tìm thấy tệp.' });
  const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml'};
  res.writeHead(200, {'Content-Type':types[path.extname(filePath)]||'application/octet-stream','Cache-Control':'no-store'});
  fs.createReadStream(filePath).pipe(res);
}

function json(res, status, body) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify(body));
}

server.listen(PORT, '127.0.0.1', () => {
  console.log(`QTTD MVP đang chạy tại http://127.0.0.1:${PORT}`);
  console.log(`SQLite: ${DATA_PATH}`);
});

function shutdown(){ server.close(() => { store.close(); process.exit(0); }); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

module.exports = { server };
